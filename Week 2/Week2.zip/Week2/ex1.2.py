length = 5
for i in range(1, length + 1):
    print("* " * i)
for i in range(length - 1, 0, -1):
    print("* " * i)
