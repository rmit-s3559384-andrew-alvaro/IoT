class py_solution:
    def reverse_string(self, s):
        return " ".join(reversed(s.split()))

print(py_solution().reverse_string("hello .py"))
